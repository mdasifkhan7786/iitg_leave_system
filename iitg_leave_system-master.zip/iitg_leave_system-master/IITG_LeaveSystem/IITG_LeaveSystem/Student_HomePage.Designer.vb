﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Student_HomePage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Student_HomePage))
        Me.NavigationGroupBox = New System.Windows.Forms.GroupBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.LogOutButton = New System.Windows.Forms.Button()
        Me.ProfileButton = New System.Windows.Forms.Button()
        Me.OldButton = New System.Windows.Forms.Button()
        Me.NAButton = New System.Windows.Forms.Button()
        Me.NAGroupBox = New System.Windows.Forms.GroupBox()
        Me.NAInnerPanel = New System.Windows.Forms.Panel()
        Me.NASupervisorLabel = New System.Windows.Forms.Label()
        Me.NASupervisorComboBox = New System.Windows.Forms.ComboBox()
        Me.NAParentalLeavesLabel = New System.Windows.Forms.Label()
        Me.NAAcademicLeavesLabel = New System.Windows.Forms.Label()
        Me.NAMedicalLeavesLabel = New System.Windows.Forms.Label()
        Me.NAOrdinaryleavesLabel = New System.Windows.Forms.Label()
        Me.NAInstructionTextBox = New System.Windows.Forms.TextBox()
        Me.NAUploadButton = New System.Windows.Forms.Button()
        Me.NAApplyButton = New System.Windows.Forms.Button()
        Me.NALeaveTypeComboBox = New System.Windows.Forms.ComboBox()
        Me.NALastDate = New System.Windows.Forms.DateTimePicker()
        Me.NAStartDate = New System.Windows.Forms.DateTimePicker()
        Me.NALastNameTextBox = New System.Windows.Forms.TextBox()
        Me.NAFirstnameTextBox = New System.Windows.Forms.TextBox()
        Me.NADocumentsLabel = New System.Windows.Forms.Label()
        Me.NALastDateLabel = New System.Windows.Forms.Label()
        Me.NAStartDateLabel = New System.Windows.Forms.Label()
        Me.NALeaveTypeLabel = New System.Windows.Forms.Label()
        Me.NALastNameLabel = New System.Windows.Forms.Label()
        Me.NAFirstNameLabel = New System.Windows.Forms.Label()
        Me.UsernameLabel = New System.Windows.Forms.Label()
        Me.HeadingLabel = New System.Windows.Forms.Label()
        Me.ProfileOpenFileDialog = New System.Windows.Forms.OpenFileDialog()
        Me.NAOpenFileDialog = New System.Windows.Forms.OpenFileDialog()
        Me.OldPanel = New System.Windows.Forms.Panel()
        Me.OldInnerPanel = New System.Windows.Forms.Panel()
        Me.OldExtendLeaveButton = New System.Windows.Forms.Button()
        Me.OldCommentsLabel = New System.Windows.Forms.Label()
        Me.OldDeleteButton = New System.Windows.Forms.Button()
        Me.OldCommentsListBox = New System.Windows.Forms.ListBox()
        Me.OldUpcomingleaveLabel = New System.Windows.Forms.Label()
        Me.OldPastLeaveLabel = New System.Windows.Forms.Label()
        Me.OldUpcomingLeavesPanel = New System.Windows.Forms.Panel()
        Me.OldUpcomingLeaveListBox = New System.Windows.Forms.ListBox()
        Me.OldPastLeavesPanel = New System.Windows.Forms.Panel()
        Me.OldPastLeaveListBox = New System.Windows.Forms.ListBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.ExtendOpenFileDialog = New System.Windows.Forms.OpenFileDialog()
        Me.NavigationouterPanel = New System.Windows.Forms.Panel()
        Me.ProfilePasswordChangePanel = New System.Windows.Forms.Panel()
        Me.ProfilePasswordChangeGroupBox = New System.Windows.Forms.GroupBox()
        Me.ProfilePasswordCheckBox = New System.Windows.Forms.CheckBox()
        Me.ProfilePasswordOkButton = New System.Windows.Forms.Button()
        Me.ProfilePasswordCancelButton = New System.Windows.Forms.Button()
        Me.ProfileNewPasswordTextBox = New System.Windows.Forms.TextBox()
        Me.ProfileConfirmNewPasswordTextBox = New System.Windows.Forms.TextBox()
        Me.ProfileOldPasswordTextBox = New System.Windows.Forms.TextBox()
        Me.ProfileConfirmNewPasswordLabel = New System.Windows.Forms.Label()
        Me.ProfileNewPasswordLabel = New System.Windows.Forms.Label()
        Me.ProfileOldPasswordLabel = New System.Windows.Forms.Label()
        Me.ExtendOuterPanel = New System.Windows.Forms.Panel()
        Me.ExtendleavePanel = New System.Windows.Forms.Panel()
        Me.ExtendLeaveInstructionTextBox = New System.Windows.Forms.TextBox()
        Me.ExtendLeaveUploadButton = New System.Windows.Forms.Button()
        Me.ExtendLeaveApplyButton = New System.Windows.Forms.Button()
        Me.ExtendLeaveCancelButton = New System.Windows.Forms.Button()
        Me.ExtendLeaveNewDocumentsLabel = New System.Windows.Forms.Label()
        Me.ExtendLeaveLastDateLabel = New System.Windows.Forms.Label()
        Me.ExtendLastDateDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.ProfileGroupBox = New System.Windows.Forms.GroupBox()
        Me.ProfileChangePasswordButton = New System.Windows.Forms.Button()
        Me.ProfileMiscellaneousLabel = New System.Windows.Forms.Label()
        Me.ProfileEditButton = New System.Windows.Forms.Button()
        Me.ProfileSaveProfileButton = New System.Windows.Forms.Button()
        Me.ProfileImageChangeButton = New System.Windows.Forms.Button()
        Me.ProfileEmergencyContactNumberTextBox = New System.Windows.Forms.TextBox()
        Me.ProfileAddressTextBox = New System.Windows.Forms.TextBox()
        Me.ProfileContactNumberTextBox = New System.Windows.Forms.TextBox()
        Me.ProfileEmailTextBox = New System.Windows.Forms.TextBox()
        Me.ProfileGenderTextBox = New System.Windows.Forms.TextBox()
        Me.ProfileDepartmentTextBox = New System.Windows.Forms.TextBox()
        Me.ProfileRollNumberTextBox = New System.Windows.Forms.TextBox()
        Me.ProfileLastNameTextBox = New System.Windows.Forms.TextBox()
        Me.ProfileFirstNameTextBox = New System.Windows.Forms.TextBox()
        Me.ProfileUserNameTextBox = New System.Windows.Forms.TextBox()
        Me.ProfilePictureBox = New System.Windows.Forms.PictureBox()
        Me.ProfileContactNumberLabel = New System.Windows.Forms.Label()
        Me.ProfileAddressLabel = New System.Windows.Forms.Label()
        Me.ProfileEmergencyContactNumberLabel = New System.Windows.Forms.Label()
        Me.ProfileEmailLabel = New System.Windows.Forms.Label()
        Me.ProfileGenderLabel = New System.Windows.Forms.Label()
        Me.ProfileDepartmentLabel = New System.Windows.Forms.Label()
        Me.ProfileFirstNameLabel = New System.Windows.Forms.Label()
        Me.ProfileLastNameLabel = New System.Windows.Forms.Label()
        Me.ProfileRollNumberLabel = New System.Windows.Forms.Label()
        Me.ProfileUserNameLabel = New System.Windows.Forms.Label()
        Me.ProfilePanel = New System.Windows.Forms.Panel()
        Me.NavigationGroupBox.SuspendLayout()
        Me.NAGroupBox.SuspendLayout()
        Me.NAInnerPanel.SuspendLayout()
        Me.OldPanel.SuspendLayout()
        Me.OldInnerPanel.SuspendLayout()
        Me.OldUpcomingLeavesPanel.SuspendLayout()
        Me.OldPastLeavesPanel.SuspendLayout()
        Me.NavigationouterPanel.SuspendLayout()
        Me.ProfilePasswordChangePanel.SuspendLayout()
        Me.ProfilePasswordChangeGroupBox.SuspendLayout()
        Me.ExtendOuterPanel.SuspendLayout()
        Me.ExtendleavePanel.SuspendLayout()
        Me.ProfileGroupBox.SuspendLayout()
        CType(Me.ProfilePictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ProfilePanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'NavigationGroupBox
        '
        Me.NavigationGroupBox.BackColor = System.Drawing.Color.LightCyan
        Me.NavigationGroupBox.Controls.Add(Me.Button1)
        Me.NavigationGroupBox.Controls.Add(Me.LogOutButton)
        Me.NavigationGroupBox.Controls.Add(Me.ProfileButton)
        Me.NavigationGroupBox.Controls.Add(Me.OldButton)
        Me.NavigationGroupBox.Controls.Add(Me.NAButton)
        Me.NavigationGroupBox.Font = New System.Drawing.Font("Georgia", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NavigationGroupBox.ForeColor = System.Drawing.Color.Black
        Me.NavigationGroupBox.Location = New System.Drawing.Point(10, 16)
        Me.NavigationGroupBox.Margin = New System.Windows.Forms.Padding(0)
        Me.NavigationGroupBox.Name = "NavigationGroupBox"
        Me.NavigationGroupBox.Size = New System.Drawing.Size(232, 772)
        Me.NavigationGroupBox.TabIndex = 1
        Me.NavigationGroupBox.TabStop = False
        Me.NavigationGroupBox.Text = "Navigation"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(184, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Georgia", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.Button1.Location = New System.Drawing.Point(0, 52)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(232, 57)
        Me.Button1.TabIndex = 4
        Me.Button1.UseVisualStyleBackColor = False
        '
        'LogOutButton
        '
        Me.LogOutButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(184, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.LogOutButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LogOutButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LogOutButton.Font = New System.Drawing.Font("Georgia", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LogOutButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.LogOutButton.Image = Global.IITG_LeaveSystem.My.Resources.Resources.logout
        Me.LogOutButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.LogOutButton.Location = New System.Drawing.Point(0, 704)
        Me.LogOutButton.Name = "LogOutButton"
        Me.LogOutButton.Size = New System.Drawing.Size(232, 57)
        Me.LogOutButton.TabIndex = 3
        Me.LogOutButton.Text = "Log Out"
        Me.LogOutButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.LogOutButton.UseVisualStyleBackColor = False
        '
        'ProfileButton
        '
        Me.ProfileButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(184, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.ProfileButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ProfileButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ProfileButton.Font = New System.Drawing.Font("Georgia", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProfileButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.ProfileButton.Image = Global.IITG_LeaveSystem.My.Resources.Resources.profile_icon
        Me.ProfileButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ProfileButton.Location = New System.Drawing.Point(0, 346)
        Me.ProfileButton.Name = "ProfileButton"
        Me.ProfileButton.Size = New System.Drawing.Size(232, 65)
        Me.ProfileButton.TabIndex = 2
        Me.ProfileButton.Text = "Profile"
        Me.ProfileButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ProfileButton.UseVisualStyleBackColor = False
        '
        'OldButton
        '
        Me.OldButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(184, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.OldButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.OldButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.OldButton.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OldButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.OldButton.Image = Global.IITG_LeaveSystem.My.Resources.Resources.old_appl
        Me.OldButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.OldButton.Location = New System.Drawing.Point(0, 238)
        Me.OldButton.Name = "OldButton"
        Me.OldButton.Size = New System.Drawing.Size(232, 76)
        Me.OldButton.TabIndex = 1
        Me.OldButton.Text = "Old Applications"
        Me.OldButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.OldButton.UseVisualStyleBackColor = False
        '
        'NAButton
        '
        Me.NAButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(184, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.NAButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.NAButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.NAButton.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NAButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.NAButton.Image = Global.IITG_LeaveSystem.My.Resources.Resources.New_Application
        Me.NAButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.NAButton.Location = New System.Drawing.Point(0, 131)
        Me.NAButton.Name = "NAButton"
        Me.NAButton.Size = New System.Drawing.Size(232, 77)
        Me.NAButton.TabIndex = 0
        Me.NAButton.Text = "New Application"
        Me.NAButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.NAButton.UseVisualStyleBackColor = False
        '
        'NAGroupBox
        '
        Me.NAGroupBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.NAGroupBox.Controls.Add(Me.NAInnerPanel)
        Me.NAGroupBox.Font = New System.Drawing.Font("Georgia", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NAGroupBox.ForeColor = System.Drawing.Color.Black
        Me.NAGroupBox.Location = New System.Drawing.Point(292, 120)
        Me.NAGroupBox.Name = "NAGroupBox"
        Me.NAGroupBox.Size = New System.Drawing.Size(882, 633)
        Me.NAGroupBox.TabIndex = 2
        Me.NAGroupBox.TabStop = False
        Me.NAGroupBox.Text = "New Application"
        '
        'NAInnerPanel
        '
        Me.NAInnerPanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.NAInnerPanel.Controls.Add(Me.NASupervisorLabel)
        Me.NAInnerPanel.Controls.Add(Me.NASupervisorComboBox)
        Me.NAInnerPanel.Controls.Add(Me.NAParentalLeavesLabel)
        Me.NAInnerPanel.Controls.Add(Me.NAAcademicLeavesLabel)
        Me.NAInnerPanel.Controls.Add(Me.NAMedicalLeavesLabel)
        Me.NAInnerPanel.Controls.Add(Me.NAOrdinaryleavesLabel)
        Me.NAInnerPanel.Controls.Add(Me.NAInstructionTextBox)
        Me.NAInnerPanel.Controls.Add(Me.NAUploadButton)
        Me.NAInnerPanel.Controls.Add(Me.NAApplyButton)
        Me.NAInnerPanel.Controls.Add(Me.NALeaveTypeComboBox)
        Me.NAInnerPanel.Controls.Add(Me.NALastDate)
        Me.NAInnerPanel.Controls.Add(Me.NAStartDate)
        Me.NAInnerPanel.Controls.Add(Me.NALastNameTextBox)
        Me.NAInnerPanel.Controls.Add(Me.NAFirstnameTextBox)
        Me.NAInnerPanel.Controls.Add(Me.NADocumentsLabel)
        Me.NAInnerPanel.Controls.Add(Me.NALastDateLabel)
        Me.NAInnerPanel.Controls.Add(Me.NAStartDateLabel)
        Me.NAInnerPanel.Controls.Add(Me.NALeaveTypeLabel)
        Me.NAInnerPanel.Controls.Add(Me.NALastNameLabel)
        Me.NAInnerPanel.Controls.Add(Me.NAFirstNameLabel)
        Me.NAInnerPanel.Location = New System.Drawing.Point(17, 28)
        Me.NAInnerPanel.Name = "NAInnerPanel"
        Me.NAInnerPanel.Size = New System.Drawing.Size(844, 582)
        Me.NAInnerPanel.TabIndex = 23
        '
        'NASupervisorLabel
        '
        Me.NASupervisorLabel.AutoSize = True
        Me.NASupervisorLabel.Font = New System.Drawing.Font("Georgia", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NASupervisorLabel.ForeColor = System.Drawing.Color.White
        Me.NASupervisorLabel.Location = New System.Drawing.Point(88, 183)
        Me.NASupervisorLabel.Name = "NASupervisorLabel"
        Me.NASupervisorLabel.Size = New System.Drawing.Size(128, 29)
        Me.NASupervisorLabel.TabIndex = 22
        Me.NASupervisorLabel.Text = "Supervisor"
        '
        'NASupervisorComboBox
        '
        Me.NASupervisorComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.NASupervisorComboBox.Location = New System.Drawing.Point(300, 176)
        Me.NASupervisorComboBox.Name = "NASupervisorComboBox"
        Me.NASupervisorComboBox.Size = New System.Drawing.Size(483, 35)
        Me.NASupervisorComboBox.TabIndex = 21
        '
        'NAParentalLeavesLabel
        '
        Me.NAParentalLeavesLabel.AutoSize = True
        Me.NAParentalLeavesLabel.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NAParentalLeavesLabel.ForeColor = System.Drawing.Color.AliceBlue
        Me.NAParentalLeavesLabel.Location = New System.Drawing.Point(6, 555)
        Me.NAParentalLeavesLabel.Name = "NAParentalLeavesLabel"
        Me.NAParentalLeavesLabel.Size = New System.Drawing.Size(184, 24)
        Me.NAParentalLeavesLabel.TabIndex = 20
        Me.NAParentalLeavesLabel.Text = "Parental Leaves: "
        '
        'NAAcademicLeavesLabel
        '
        Me.NAAcademicLeavesLabel.AutoSize = True
        Me.NAAcademicLeavesLabel.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NAAcademicLeavesLabel.ForeColor = System.Drawing.Color.AliceBlue
        Me.NAAcademicLeavesLabel.Location = New System.Drawing.Point(6, 485)
        Me.NAAcademicLeavesLabel.Name = "NAAcademicLeavesLabel"
        Me.NAAcademicLeavesLabel.Size = New System.Drawing.Size(196, 24)
        Me.NAAcademicLeavesLabel.TabIndex = 19
        Me.NAAcademicLeavesLabel.Text = "Academic Leaves: "
        '
        'NAMedicalLeavesLabel
        '
        Me.NAMedicalLeavesLabel.AutoSize = True
        Me.NAMedicalLeavesLabel.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NAMedicalLeavesLabel.ForeColor = System.Drawing.Color.AliceBlue
        Me.NAMedicalLeavesLabel.Location = New System.Drawing.Point(6, 518)
        Me.NAMedicalLeavesLabel.Name = "NAMedicalLeavesLabel"
        Me.NAMedicalLeavesLabel.Size = New System.Drawing.Size(177, 24)
        Me.NAMedicalLeavesLabel.TabIndex = 18
        Me.NAMedicalLeavesLabel.Text = "Medical Leaves: "
        '
        'NAOrdinaryleavesLabel
        '
        Me.NAOrdinaryleavesLabel.AutoSize = True
        Me.NAOrdinaryleavesLabel.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NAOrdinaryleavesLabel.ForeColor = System.Drawing.Color.AliceBlue
        Me.NAOrdinaryleavesLabel.Location = New System.Drawing.Point(6, 449)
        Me.NAOrdinaryleavesLabel.Name = "NAOrdinaryleavesLabel"
        Me.NAOrdinaryleavesLabel.Size = New System.Drawing.Size(189, 24)
        Me.NAOrdinaryleavesLabel.TabIndex = 17
        Me.NAOrdinaryleavesLabel.Text = "Ordinary Leaves: "
        '
        'NAInstructionTextBox
        '
        Me.NAInstructionTextBox.BackColor = System.Drawing.Color.AliceBlue
        Me.NAInstructionTextBox.Location = New System.Drawing.Point(366, 453)
        Me.NAInstructionTextBox.Name = "NAInstructionTextBox"
        Me.NAInstructionTextBox.ReadOnly = True
        Me.NAInstructionTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal
        Me.NAInstructionTextBox.Size = New System.Drawing.Size(452, 34)
        Me.NAInstructionTextBox.TabIndex = 16
        '
        'NAUploadButton
        '
        Me.NAUploadButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(184, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.NAUploadButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.NAUploadButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.NAUploadButton.Location = New System.Drawing.Point(366, 376)
        Me.NAUploadButton.Name = "NAUploadButton"
        Me.NAUploadButton.Size = New System.Drawing.Size(154, 52)
        Me.NAUploadButton.TabIndex = 15
        Me.NAUploadButton.Text = "Upload"
        Me.NAUploadButton.UseVisualStyleBackColor = False
        '
        'NAApplyButton
        '
        Me.NAApplyButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(184, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.NAApplyButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.NAApplyButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.NAApplyButton.Location = New System.Drawing.Point(674, 527)
        Me.NAApplyButton.Name = "NAApplyButton"
        Me.NAApplyButton.Size = New System.Drawing.Size(144, 50)
        Me.NAApplyButton.TabIndex = 14
        Me.NAApplyButton.Text = "Apply"
        Me.NAApplyButton.UseVisualStyleBackColor = False
        '
        'NALeaveTypeComboBox
        '
        Me.NALeaveTypeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.NALeaveTypeComboBox.FormattingEnabled = True
        Me.NALeaveTypeComboBox.Location = New System.Drawing.Point(299, 113)
        Me.NALeaveTypeComboBox.Name = "NALeaveTypeComboBox"
        Me.NALeaveTypeComboBox.Size = New System.Drawing.Size(484, 35)
        Me.NALeaveTypeComboBox.TabIndex = 13
        '
        'NALastDate
        '
        Me.NALastDate.CustomFormat = "DD-MM-YYYY"
        Me.NALastDate.Location = New System.Drawing.Point(300, 301)
        Me.NALastDate.MinDate = New Date(2019, 1, 1, 0, 0, 0, 0)
        Me.NALastDate.Name = "NALastDate"
        Me.NALastDate.Size = New System.Drawing.Size(483, 34)
        Me.NALastDate.TabIndex = 12
        '
        'NAStartDate
        '
        Me.NAStartDate.CustomFormat = "DD-MM-YYYY"
        Me.NAStartDate.Location = New System.Drawing.Point(300, 239)
        Me.NAStartDate.MinDate = New Date(2019, 1, 1, 0, 0, 0, 0)
        Me.NAStartDate.Name = "NAStartDate"
        Me.NAStartDate.Size = New System.Drawing.Size(483, 34)
        Me.NAStartDate.TabIndex = 11
        '
        'NALastNameTextBox
        '
        Me.NALastNameTextBox.Location = New System.Drawing.Point(300, 55)
        Me.NALastNameTextBox.Name = "NALastNameTextBox"
        Me.NALastNameTextBox.ReadOnly = True
        Me.NALastNameTextBox.Size = New System.Drawing.Size(484, 34)
        Me.NALastNameTextBox.TabIndex = 7
        '
        'NAFirstnameTextBox
        '
        Me.NAFirstnameTextBox.Location = New System.Drawing.Point(299, 12)
        Me.NAFirstnameTextBox.Name = "NAFirstnameTextBox"
        Me.NAFirstnameTextBox.ReadOnly = True
        Me.NAFirstnameTextBox.Size = New System.Drawing.Size(485, 34)
        Me.NAFirstnameTextBox.TabIndex = 6
        '
        'NADocumentsLabel
        '
        Me.NADocumentsLabel.AutoSize = True
        Me.NADocumentsLabel.Font = New System.Drawing.Font("Georgia", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NADocumentsLabel.ForeColor = System.Drawing.Color.White
        Me.NADocumentsLabel.Location = New System.Drawing.Point(88, 384)
        Me.NADocumentsLabel.Name = "NADocumentsLabel"
        Me.NADocumentsLabel.Size = New System.Drawing.Size(208, 29)
        Me.NADocumentsLabel.TabIndex = 5
        Me.NADocumentsLabel.Text = "Document Upload"
        '
        'NALastDateLabel
        '
        Me.NALastDateLabel.AutoSize = True
        Me.NALastDateLabel.Font = New System.Drawing.Font("Georgia", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NALastDateLabel.ForeColor = System.Drawing.Color.White
        Me.NALastDateLabel.Location = New System.Drawing.Point(88, 301)
        Me.NALastDateLabel.Name = "NALastDateLabel"
        Me.NALastDateLabel.Size = New System.Drawing.Size(113, 29)
        Me.NALastDateLabel.TabIndex = 4
        Me.NALastDateLabel.Text = "Last Date"
        '
        'NAStartDateLabel
        '
        Me.NAStartDateLabel.AutoSize = True
        Me.NAStartDateLabel.Font = New System.Drawing.Font("Georgia", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NAStartDateLabel.ForeColor = System.Drawing.Color.White
        Me.NAStartDateLabel.Location = New System.Drawing.Point(88, 244)
        Me.NAStartDateLabel.Name = "NAStartDateLabel"
        Me.NAStartDateLabel.Size = New System.Drawing.Size(120, 29)
        Me.NAStartDateLabel.TabIndex = 3
        Me.NAStartDateLabel.Text = "Start Date"
        '
        'NALeaveTypeLabel
        '
        Me.NALeaveTypeLabel.AutoSize = True
        Me.NALeaveTypeLabel.Font = New System.Drawing.Font("Georgia", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NALeaveTypeLabel.ForeColor = System.Drawing.Color.White
        Me.NALeaveTypeLabel.Location = New System.Drawing.Point(88, 116)
        Me.NALeaveTypeLabel.Name = "NALeaveTypeLabel"
        Me.NALeaveTypeLabel.Size = New System.Drawing.Size(134, 29)
        Me.NALeaveTypeLabel.TabIndex = 2
        Me.NALeaveTypeLabel.Text = "Leave Type"
        '
        'NALastNameLabel
        '
        Me.NALastNameLabel.AutoSize = True
        Me.NALastNameLabel.Font = New System.Drawing.Font("Georgia", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NALastNameLabel.ForeColor = System.Drawing.Color.White
        Me.NALastNameLabel.Location = New System.Drawing.Point(88, 61)
        Me.NALastNameLabel.Name = "NALastNameLabel"
        Me.NALastNameLabel.Size = New System.Drawing.Size(126, 29)
        Me.NALastNameLabel.TabIndex = 1
        Me.NALastNameLabel.Text = "Last Name"
        '
        'NAFirstNameLabel
        '
        Me.NAFirstNameLabel.AutoSize = True
        Me.NAFirstNameLabel.Font = New System.Drawing.Font("Georgia", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NAFirstNameLabel.ForeColor = System.Drawing.Color.White
        Me.NAFirstNameLabel.Location = New System.Drawing.Point(88, 13)
        Me.NAFirstNameLabel.Name = "NAFirstNameLabel"
        Me.NAFirstNameLabel.Size = New System.Drawing.Size(131, 29)
        Me.NAFirstNameLabel.TabIndex = 0
        Me.NAFirstNameLabel.Text = "First Name"
        '
        'UsernameLabel
        '
        Me.UsernameLabel.AutoSize = True
        Me.UsernameLabel.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UsernameLabel.ForeColor = System.Drawing.Color.AliceBlue
        Me.UsernameLabel.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.UsernameLabel.Location = New System.Drawing.Point(926, 32)
        Me.UsernameLabel.Name = "UsernameLabel"
        Me.UsernameLabel.Size = New System.Drawing.Size(59, 24)
        Me.UsernameLabel.TabIndex = 3
        Me.UsernameLabel.Text = "Label"
        '
        'HeadingLabel
        '
        Me.HeadingLabel.AutoSize = True
        Me.HeadingLabel.Font = New System.Drawing.Font("Georgia", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HeadingLabel.ForeColor = System.Drawing.Color.White
        Me.HeadingLabel.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.HeadingLabel.Location = New System.Drawing.Point(260, 14)
        Me.HeadingLabel.Name = "HeadingLabel"
        Me.HeadingLabel.Size = New System.Drawing.Size(451, 46)
        Me.HeadingLabel.TabIndex = 4
        Me.HeadingLabel.Text = "Student Leave Portal"
        '
        'ProfileOpenFileDialog
        '
        Me.ProfileOpenFileDialog.FileName = "ProfileOpenFileDialog"
        Me.ProfileOpenFileDialog.Filter = "Jpeg (*.jpeg)|*.jpeg"
        '
        'NAOpenFileDialog
        '
        Me.NAOpenFileDialog.FileName = "NAOpenFileDialog"
        Me.NAOpenFileDialog.Filter = "Pdf (*.pdf)| *.pdf"
        '
        'OldPanel
        '
        Me.OldPanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.OldPanel.Controls.Add(Me.OldInnerPanel)
        Me.OldPanel.Location = New System.Drawing.Point(259, 133)
        Me.OldPanel.Name = "OldPanel"
        Me.OldPanel.Size = New System.Drawing.Size(965, 597)
        Me.OldPanel.TabIndex = 8
        '
        'OldInnerPanel
        '
        Me.OldInnerPanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.OldInnerPanel.Controls.Add(Me.OldExtendLeaveButton)
        Me.OldInnerPanel.Controls.Add(Me.OldCommentsLabel)
        Me.OldInnerPanel.Controls.Add(Me.OldDeleteButton)
        Me.OldInnerPanel.Controls.Add(Me.OldCommentsListBox)
        Me.OldInnerPanel.Controls.Add(Me.OldUpcomingleaveLabel)
        Me.OldInnerPanel.Controls.Add(Me.OldPastLeaveLabel)
        Me.OldInnerPanel.Controls.Add(Me.OldUpcomingLeavesPanel)
        Me.OldInnerPanel.Controls.Add(Me.OldPastLeavesPanel)
        Me.OldInnerPanel.Location = New System.Drawing.Point(9, 12)
        Me.OldInnerPanel.Margin = New System.Windows.Forms.Padding(0)
        Me.OldInnerPanel.Name = "OldInnerPanel"
        Me.OldInnerPanel.Size = New System.Drawing.Size(942, 575)
        Me.OldInnerPanel.TabIndex = 8
        '
        'OldExtendLeaveButton
        '
        Me.OldExtendLeaveButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(78, Byte), Integer), CType(CType(184, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.OldExtendLeaveButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.OldExtendLeaveButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.OldExtendLeaveButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.OldExtendLeaveButton.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OldExtendLeaveButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.OldExtendLeaveButton.Location = New System.Drawing.Point(431, 503)
        Me.OldExtendLeaveButton.Name = "OldExtendLeaveButton"
        Me.OldExtendLeaveButton.Size = New System.Drawing.Size(248, 63)
        Me.OldExtendLeaveButton.TabIndex = 7
        Me.OldExtendLeaveButton.Text = "Modify Application"
        Me.OldExtendLeaveButton.UseVisualStyleBackColor = False
        '
        'OldCommentsLabel
        '
        Me.OldCommentsLabel.AutoSize = True
        Me.OldCommentsLabel.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OldCommentsLabel.ForeColor = System.Drawing.Color.White
        Me.OldCommentsLabel.Location = New System.Drawing.Point(23, 363)
        Me.OldCommentsLabel.Name = "OldCommentsLabel"
        Me.OldCommentsLabel.Size = New System.Drawing.Size(108, 24)
        Me.OldCommentsLabel.TabIndex = 6
        Me.OldCommentsLabel.Text = "Comments"
        '
        'OldDeleteButton
        '
        Me.OldDeleteButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(78, Byte), Integer), CType(CType(184, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.OldDeleteButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.OldDeleteButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.OldDeleteButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.OldDeleteButton.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OldDeleteButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.OldDeleteButton.Location = New System.Drawing.Point(695, 503)
        Me.OldDeleteButton.Name = "OldDeleteButton"
        Me.OldDeleteButton.Size = New System.Drawing.Size(232, 63)
        Me.OldDeleteButton.TabIndex = 5
        Me.OldDeleteButton.Text = "Delete Application"
        Me.OldDeleteButton.UseVisualStyleBackColor = False
        '
        'OldCommentsListBox
        '
        Me.OldCommentsListBox.BackColor = System.Drawing.Color.LightCyan
        Me.OldCommentsListBox.Font = New System.Drawing.Font("Georgia", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OldCommentsListBox.FormattingEnabled = True
        Me.OldCommentsListBox.HorizontalExtent = 1000
        Me.OldCommentsListBox.HorizontalScrollbar = True
        Me.OldCommentsListBox.ItemHeight = 20
        Me.OldCommentsListBox.Location = New System.Drawing.Point(16, 391)
        Me.OldCommentsListBox.Name = "OldCommentsListBox"
        Me.OldCommentsListBox.Size = New System.Drawing.Size(911, 104)
        Me.OldCommentsListBox.TabIndex = 4
        '
        'OldUpcomingleaveLabel
        '
        Me.OldUpcomingleaveLabel.AutoSize = True
        Me.OldUpcomingleaveLabel.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OldUpcomingleaveLabel.ForeColor = System.Drawing.Color.White
        Me.OldUpcomingleaveLabel.Location = New System.Drawing.Point(469, 20)
        Me.OldUpcomingleaveLabel.Name = "OldUpcomingleaveLabel"
        Me.OldUpcomingleaveLabel.Size = New System.Drawing.Size(354, 24)
        Me.OldUpcomingleaveLabel.TabIndex = 3
        Me.OldUpcomingleaveLabel.Text = "Upcoming/Ongoing leave Applications"
        '
        'OldPastLeaveLabel
        '
        Me.OldPastLeaveLabel.AutoSize = True
        Me.OldPastLeaveLabel.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OldPastLeaveLabel.ForeColor = System.Drawing.Color.White
        Me.OldPastLeaveLabel.Location = New System.Drawing.Point(11, 20)
        Me.OldPastLeaveLabel.Name = "OldPastLeaveLabel"
        Me.OldPastLeaveLabel.Size = New System.Drawing.Size(215, 24)
        Me.OldPastLeaveLabel.TabIndex = 2
        Me.OldPastLeaveLabel.Text = "Past leave Applications"
        '
        'OldUpcomingLeavesPanel
        '
        Me.OldUpcomingLeavesPanel.AutoScroll = True
        Me.OldUpcomingLeavesPanel.Controls.Add(Me.OldUpcomingLeaveListBox)
        Me.OldUpcomingLeavesPanel.Location = New System.Drawing.Point(471, 58)
        Me.OldUpcomingLeavesPanel.Name = "OldUpcomingLeavesPanel"
        Me.OldUpcomingLeavesPanel.Size = New System.Drawing.Size(463, 310)
        Me.OldUpcomingLeavesPanel.TabIndex = 1
        '
        'OldUpcomingLeaveListBox
        '
        Me.OldUpcomingLeaveListBox.BackColor = System.Drawing.Color.LightCyan
        Me.OldUpcomingLeaveListBox.Font = New System.Drawing.Font("Georgia", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OldUpcomingLeaveListBox.FormattingEnabled = True
        Me.OldUpcomingLeaveListBox.HorizontalExtent = 800
        Me.OldUpcomingLeaveListBox.HorizontalScrollbar = True
        Me.OldUpcomingLeaveListBox.ItemHeight = 20
        Me.OldUpcomingLeaveListBox.Location = New System.Drawing.Point(3, 9)
        Me.OldUpcomingLeaveListBox.Name = "OldUpcomingLeaveListBox"
        Me.OldUpcomingLeaveListBox.ScrollAlwaysVisible = True
        Me.OldUpcomingLeaveListBox.Size = New System.Drawing.Size(454, 284)
        Me.OldUpcomingLeaveListBox.TabIndex = 1
        '
        'OldPastLeavesPanel
        '
        Me.OldPastLeavesPanel.AutoScroll = True
        Me.OldPastLeavesPanel.Controls.Add(Me.OldPastLeaveListBox)
        Me.OldPastLeavesPanel.Location = New System.Drawing.Point(4, 58)
        Me.OldPastLeavesPanel.Name = "OldPastLeavesPanel"
        Me.OldPastLeavesPanel.Size = New System.Drawing.Size(457, 310)
        Me.OldPastLeavesPanel.TabIndex = 0
        '
        'OldPastLeaveListBox
        '
        Me.OldPastLeaveListBox.BackColor = System.Drawing.Color.LightCyan
        Me.OldPastLeaveListBox.Font = New System.Drawing.Font("Georgia", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OldPastLeaveListBox.FormattingEnabled = True
        Me.OldPastLeaveListBox.HorizontalExtent = 800
        Me.OldPastLeaveListBox.HorizontalScrollbar = True
        Me.OldPastLeaveListBox.ItemHeight = 20
        Me.OldPastLeaveListBox.Location = New System.Drawing.Point(12, 11)
        Me.OldPastLeaveListBox.Name = "OldPastLeaveListBox"
        Me.OldPastLeaveListBox.ScrollAlwaysVisible = True
        Me.OldPastLeaveListBox.Size = New System.Drawing.Size(442, 284)
        Me.OldPastLeaveListBox.TabIndex = 0
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'ExtendOpenFileDialog
        '
        Me.ExtendOpenFileDialog.FileName = "ExtendOpenFileDialog"
        Me.ExtendOpenFileDialog.Filter = "Pdf (*.pdf)| *.pdf"
        '
        'NavigationouterPanel
        '
        Me.NavigationouterPanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.NavigationouterPanel.Controls.Add(Me.NavigationGroupBox)
        Me.NavigationouterPanel.Location = New System.Drawing.Point(-1, -2)
        Me.NavigationouterPanel.Margin = New System.Windows.Forms.Padding(0)
        Me.NavigationouterPanel.Name = "NavigationouterPanel"
        Me.NavigationouterPanel.Size = New System.Drawing.Size(257, 800)
        Me.NavigationouterPanel.TabIndex = 5
        '
        'ProfilePasswordChangePanel
        '
        Me.ProfilePasswordChangePanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ProfilePasswordChangePanel.Controls.Add(Me.ProfilePasswordChangeGroupBox)
        Me.ProfilePasswordChangePanel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProfilePasswordChangePanel.Location = New System.Drawing.Point(402, 180)
        Me.ProfilePasswordChangePanel.Name = "ProfilePasswordChangePanel"
        Me.ProfilePasswordChangePanel.Size = New System.Drawing.Size(667, 455)
        Me.ProfilePasswordChangePanel.TabIndex = 9
        '
        'ProfilePasswordChangeGroupBox
        '
        Me.ProfilePasswordChangeGroupBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.ProfilePasswordChangeGroupBox.Controls.Add(Me.ProfilePasswordCheckBox)
        Me.ProfilePasswordChangeGroupBox.Controls.Add(Me.ProfilePasswordOkButton)
        Me.ProfilePasswordChangeGroupBox.Controls.Add(Me.ProfilePasswordCancelButton)
        Me.ProfilePasswordChangeGroupBox.Controls.Add(Me.ProfileNewPasswordTextBox)
        Me.ProfilePasswordChangeGroupBox.Controls.Add(Me.ProfileConfirmNewPasswordTextBox)
        Me.ProfilePasswordChangeGroupBox.Controls.Add(Me.ProfileOldPasswordTextBox)
        Me.ProfilePasswordChangeGroupBox.Controls.Add(Me.ProfileConfirmNewPasswordLabel)
        Me.ProfilePasswordChangeGroupBox.Controls.Add(Me.ProfileNewPasswordLabel)
        Me.ProfilePasswordChangeGroupBox.Controls.Add(Me.ProfileOldPasswordLabel)
        Me.ProfilePasswordChangeGroupBox.Font = New System.Drawing.Font("Georgia", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProfilePasswordChangeGroupBox.ForeColor = System.Drawing.Color.White
        Me.ProfilePasswordChangeGroupBox.Location = New System.Drawing.Point(10, 12)
        Me.ProfilePasswordChangeGroupBox.Name = "ProfilePasswordChangeGroupBox"
        Me.ProfilePasswordChangeGroupBox.Size = New System.Drawing.Size(643, 424)
        Me.ProfilePasswordChangeGroupBox.TabIndex = 0
        Me.ProfilePasswordChangeGroupBox.TabStop = False
        Me.ProfilePasswordChangeGroupBox.Text = "Password Change"
        '
        'ProfilePasswordCheckBox
        '
        Me.ProfilePasswordCheckBox.AutoSize = True
        Me.ProfilePasswordCheckBox.Font = New System.Drawing.Font("Georgia", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProfilePasswordCheckBox.ForeColor = System.Drawing.Color.White
        Me.ProfilePasswordCheckBox.Location = New System.Drawing.Point(323, 227)
        Me.ProfilePasswordCheckBox.Name = "ProfilePasswordCheckBox"
        Me.ProfilePasswordCheckBox.Size = New System.Drawing.Size(149, 24)
        Me.ProfilePasswordCheckBox.TabIndex = 8
        Me.ProfilePasswordCheckBox.Text = "Show Password"
        Me.ProfilePasswordCheckBox.UseMnemonic = False
        Me.ProfilePasswordCheckBox.UseVisualStyleBackColor = True
        '
        'ProfilePasswordOkButton
        '
        Me.ProfilePasswordOkButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(78, Byte), Integer), CType(CType(184, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.ProfilePasswordOkButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ProfilePasswordOkButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.ProfilePasswordOkButton.Location = New System.Drawing.Point(327, 353)
        Me.ProfilePasswordOkButton.Name = "ProfilePasswordOkButton"
        Me.ProfilePasswordOkButton.Size = New System.Drawing.Size(148, 49)
        Me.ProfilePasswordOkButton.TabIndex = 7
        Me.ProfilePasswordOkButton.Text = "Ok"
        Me.ProfilePasswordOkButton.UseVisualStyleBackColor = False
        '
        'ProfilePasswordCancelButton
        '
        Me.ProfilePasswordCancelButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(78, Byte), Integer), CType(CType(184, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.ProfilePasswordCancelButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ProfilePasswordCancelButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ProfilePasswordCancelButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.ProfilePasswordCancelButton.Location = New System.Drawing.Point(170, 353)
        Me.ProfilePasswordCancelButton.Name = "ProfilePasswordCancelButton"
        Me.ProfilePasswordCancelButton.Size = New System.Drawing.Size(144, 49)
        Me.ProfilePasswordCancelButton.TabIndex = 6
        Me.ProfilePasswordCancelButton.Text = "Cancel"
        Me.ProfilePasswordCancelButton.UseVisualStyleBackColor = False
        '
        'ProfileNewPasswordTextBox
        '
        Me.ProfileNewPasswordTextBox.Location = New System.Drawing.Point(323, 111)
        Me.ProfileNewPasswordTextBox.Name = "ProfileNewPasswordTextBox"
        Me.ProfileNewPasswordTextBox.Size = New System.Drawing.Size(282, 34)
        Me.ProfileNewPasswordTextBox.TabIndex = 5
        '
        'ProfileConfirmNewPasswordTextBox
        '
        Me.ProfileConfirmNewPasswordTextBox.Location = New System.Drawing.Point(323, 176)
        Me.ProfileConfirmNewPasswordTextBox.Name = "ProfileConfirmNewPasswordTextBox"
        Me.ProfileConfirmNewPasswordTextBox.Size = New System.Drawing.Size(282, 34)
        Me.ProfileConfirmNewPasswordTextBox.TabIndex = 4
        '
        'ProfileOldPasswordTextBox
        '
        Me.ProfileOldPasswordTextBox.Location = New System.Drawing.Point(323, 54)
        Me.ProfileOldPasswordTextBox.Name = "ProfileOldPasswordTextBox"
        Me.ProfileOldPasswordTextBox.Size = New System.Drawing.Size(282, 34)
        Me.ProfileOldPasswordTextBox.TabIndex = 3
        '
        'ProfileConfirmNewPasswordLabel
        '
        Me.ProfileConfirmNewPasswordLabel.AutoSize = True
        Me.ProfileConfirmNewPasswordLabel.Font = New System.Drawing.Font("Georgia", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProfileConfirmNewPasswordLabel.ForeColor = System.Drawing.Color.White
        Me.ProfileConfirmNewPasswordLabel.Location = New System.Drawing.Point(30, 181)
        Me.ProfileConfirmNewPasswordLabel.Name = "ProfileConfirmNewPasswordLabel"
        Me.ProfileConfirmNewPasswordLabel.Size = New System.Drawing.Size(209, 23)
        Me.ProfileConfirmNewPasswordLabel.TabIndex = 2
        Me.ProfileConfirmNewPasswordLabel.Text = "Confirm New Password"
        '
        'ProfileNewPasswordLabel
        '
        Me.ProfileNewPasswordLabel.AutoSize = True
        Me.ProfileNewPasswordLabel.Font = New System.Drawing.Font("Georgia", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProfileNewPasswordLabel.ForeColor = System.Drawing.Color.White
        Me.ProfileNewPasswordLabel.Location = New System.Drawing.Point(33, 117)
        Me.ProfileNewPasswordLabel.Name = "ProfileNewPasswordLabel"
        Me.ProfileNewPasswordLabel.Size = New System.Drawing.Size(134, 23)
        Me.ProfileNewPasswordLabel.TabIndex = 1
        Me.ProfileNewPasswordLabel.Text = "New Password"
        '
        'ProfileOldPasswordLabel
        '
        Me.ProfileOldPasswordLabel.AutoSize = True
        Me.ProfileOldPasswordLabel.Font = New System.Drawing.Font("Georgia", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProfileOldPasswordLabel.ForeColor = System.Drawing.Color.White
        Me.ProfileOldPasswordLabel.Location = New System.Drawing.Point(30, 57)
        Me.ProfileOldPasswordLabel.Name = "ProfileOldPasswordLabel"
        Me.ProfileOldPasswordLabel.Size = New System.Drawing.Size(126, 23)
        Me.ProfileOldPasswordLabel.TabIndex = 0
        Me.ProfileOldPasswordLabel.Text = "Old Password"
        '
        'ExtendOuterPanel
        '
        Me.ExtendOuterPanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ExtendOuterPanel.Controls.Add(Me.ExtendleavePanel)
        Me.ExtendOuterPanel.Location = New System.Drawing.Point(387, 168)
        Me.ExtendOuterPanel.Name = "ExtendOuterPanel"
        Me.ExtendOuterPanel.Size = New System.Drawing.Size(690, 459)
        Me.ExtendOuterPanel.TabIndex = 29
        '
        'ExtendleavePanel
        '
        Me.ExtendleavePanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.ExtendleavePanel.Controls.Add(Me.ExtendLeaveInstructionTextBox)
        Me.ExtendleavePanel.Controls.Add(Me.ExtendLeaveUploadButton)
        Me.ExtendleavePanel.Controls.Add(Me.ExtendLeaveApplyButton)
        Me.ExtendleavePanel.Controls.Add(Me.ExtendLeaveCancelButton)
        Me.ExtendleavePanel.Controls.Add(Me.ExtendLeaveNewDocumentsLabel)
        Me.ExtendleavePanel.Controls.Add(Me.ExtendLeaveLastDateLabel)
        Me.ExtendleavePanel.Controls.Add(Me.ExtendLastDateDateTimePicker)
        Me.ExtendleavePanel.Location = New System.Drawing.Point(10, 10)
        Me.ExtendleavePanel.Name = "ExtendleavePanel"
        Me.ExtendleavePanel.Size = New System.Drawing.Size(666, 440)
        Me.ExtendleavePanel.TabIndex = 28
        '
        'ExtendLeaveInstructionTextBox
        '
        Me.ExtendLeaveInstructionTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.ExtendLeaveInstructionTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ExtendLeaveInstructionTextBox.Font = New System.Drawing.Font("Georgia", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExtendLeaveInstructionTextBox.ForeColor = System.Drawing.Color.White
        Me.ExtendLeaveInstructionTextBox.Location = New System.Drawing.Point(278, 201)
        Me.ExtendLeaveInstructionTextBox.Name = "ExtendLeaveInstructionTextBox"
        Me.ExtendLeaveInstructionTextBox.ReadOnly = True
        Me.ExtendLeaveInstructionTextBox.Size = New System.Drawing.Size(125, 15)
        Me.ExtendLeaveInstructionTextBox.TabIndex = 7
        Me.ExtendLeaveInstructionTextBox.Text = "pdf only"
        '
        'ExtendLeaveUploadButton
        '
        Me.ExtendLeaveUploadButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(78, Byte), Integer), CType(CType(184, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ExtendLeaveUploadButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ExtendLeaveUploadButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ExtendLeaveUploadButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ExtendLeaveUploadButton.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExtendLeaveUploadButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.ExtendLeaveUploadButton.Location = New System.Drawing.Point(278, 145)
        Me.ExtendLeaveUploadButton.Name = "ExtendLeaveUploadButton"
        Me.ExtendLeaveUploadButton.Size = New System.Drawing.Size(150, 46)
        Me.ExtendLeaveUploadButton.TabIndex = 6
        Me.ExtendLeaveUploadButton.Text = "Upload"
        Me.ExtendLeaveUploadButton.UseVisualStyleBackColor = False
        '
        'ExtendLeaveApplyButton
        '
        Me.ExtendLeaveApplyButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(78, Byte), Integer), CType(CType(184, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ExtendLeaveApplyButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ExtendLeaveApplyButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ExtendLeaveApplyButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ExtendLeaveApplyButton.Font = New System.Drawing.Font("Georgia", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExtendLeaveApplyButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.ExtendLeaveApplyButton.Location = New System.Drawing.Point(359, 336)
        Me.ExtendLeaveApplyButton.Name = "ExtendLeaveApplyButton"
        Me.ExtendLeaveApplyButton.Size = New System.Drawing.Size(191, 53)
        Me.ExtendLeaveApplyButton.TabIndex = 5
        Me.ExtendLeaveApplyButton.Text = "Apply"
        Me.ExtendLeaveApplyButton.UseVisualStyleBackColor = False
        '
        'ExtendLeaveCancelButton
        '
        Me.ExtendLeaveCancelButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(78, Byte), Integer), CType(CType(184, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ExtendLeaveCancelButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ExtendLeaveCancelButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ExtendLeaveCancelButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ExtendLeaveCancelButton.Font = New System.Drawing.Font("Georgia", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExtendLeaveCancelButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.ExtendLeaveCancelButton.Location = New System.Drawing.Point(132, 336)
        Me.ExtendLeaveCancelButton.Name = "ExtendLeaveCancelButton"
        Me.ExtendLeaveCancelButton.Size = New System.Drawing.Size(204, 53)
        Me.ExtendLeaveCancelButton.TabIndex = 3
        Me.ExtendLeaveCancelButton.Text = "Back"
        Me.ExtendLeaveCancelButton.UseVisualStyleBackColor = False
        '
        'ExtendLeaveNewDocumentsLabel
        '
        Me.ExtendLeaveNewDocumentsLabel.AutoSize = True
        Me.ExtendLeaveNewDocumentsLabel.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExtendLeaveNewDocumentsLabel.ForeColor = System.Drawing.Color.White
        Me.ExtendLeaveNewDocumentsLabel.Location = New System.Drawing.Point(23, 159)
        Me.ExtendLeaveNewDocumentsLabel.Name = "ExtendLeaveNewDocumentsLabel"
        Me.ExtendLeaveNewDocumentsLabel.Size = New System.Drawing.Size(158, 24)
        Me.ExtendLeaveNewDocumentsLabel.TabIndex = 2
        Me.ExtendLeaveNewDocumentsLabel.Text = "New Documents"
        '
        'ExtendLeaveLastDateLabel
        '
        Me.ExtendLeaveLastDateLabel.AutoSize = True
        Me.ExtendLeaveLastDateLabel.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExtendLeaveLastDateLabel.ForeColor = System.Drawing.Color.White
        Me.ExtendLeaveLastDateLabel.Location = New System.Drawing.Point(23, 70)
        Me.ExtendLeaveLastDateLabel.Name = "ExtendLeaveLastDateLabel"
        Me.ExtendLeaveLastDateLabel.Size = New System.Drawing.Size(140, 24)
        Me.ExtendLeaveLastDateLabel.TabIndex = 1
        Me.ExtendLeaveLastDateLabel.Text = "New Last Date"
        '
        'ExtendLastDateDateTimePicker
        '
        Me.ExtendLastDateDateTimePicker.CustomFormat = "DD-MM-YYYY"
        Me.ExtendLastDateDateTimePicker.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExtendLastDateDateTimePicker.Location = New System.Drawing.Point(227, 71)
        Me.ExtendLastDateDateTimePicker.Name = "ExtendLastDateDateTimePicker"
        Me.ExtendLastDateDateTimePicker.Size = New System.Drawing.Size(416, 28)
        Me.ExtendLastDateDateTimePicker.TabIndex = 0
        '
        'ProfileGroupBox
        '
        Me.ProfileGroupBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.ProfileGroupBox.Controls.Add(Me.ProfileChangePasswordButton)
        Me.ProfileGroupBox.Controls.Add(Me.ProfileMiscellaneousLabel)
        Me.ProfileGroupBox.Controls.Add(Me.ProfileEditButton)
        Me.ProfileGroupBox.Controls.Add(Me.ProfileSaveProfileButton)
        Me.ProfileGroupBox.Controls.Add(Me.ProfileImageChangeButton)
        Me.ProfileGroupBox.Controls.Add(Me.ProfileEmergencyContactNumberTextBox)
        Me.ProfileGroupBox.Controls.Add(Me.ProfileAddressTextBox)
        Me.ProfileGroupBox.Controls.Add(Me.ProfileContactNumberTextBox)
        Me.ProfileGroupBox.Controls.Add(Me.ProfileEmailTextBox)
        Me.ProfileGroupBox.Controls.Add(Me.ProfileGenderTextBox)
        Me.ProfileGroupBox.Controls.Add(Me.ProfileDepartmentTextBox)
        Me.ProfileGroupBox.Controls.Add(Me.ProfileRollNumberTextBox)
        Me.ProfileGroupBox.Controls.Add(Me.ProfileLastNameTextBox)
        Me.ProfileGroupBox.Controls.Add(Me.ProfileFirstNameTextBox)
        Me.ProfileGroupBox.Controls.Add(Me.ProfileUserNameTextBox)
        Me.ProfileGroupBox.Controls.Add(Me.ProfilePictureBox)
        Me.ProfileGroupBox.Controls.Add(Me.ProfileContactNumberLabel)
        Me.ProfileGroupBox.Controls.Add(Me.ProfileAddressLabel)
        Me.ProfileGroupBox.Controls.Add(Me.ProfileEmergencyContactNumberLabel)
        Me.ProfileGroupBox.Controls.Add(Me.ProfileEmailLabel)
        Me.ProfileGroupBox.Controls.Add(Me.ProfileGenderLabel)
        Me.ProfileGroupBox.Controls.Add(Me.ProfileDepartmentLabel)
        Me.ProfileGroupBox.Controls.Add(Me.ProfileFirstNameLabel)
        Me.ProfileGroupBox.Controls.Add(Me.ProfileLastNameLabel)
        Me.ProfileGroupBox.Controls.Add(Me.ProfileRollNumberLabel)
        Me.ProfileGroupBox.Controls.Add(Me.ProfileUserNameLabel)
        Me.ProfileGroupBox.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProfileGroupBox.ForeColor = System.Drawing.Color.White
        Me.ProfileGroupBox.Location = New System.Drawing.Point(16, 12)
        Me.ProfileGroupBox.Name = "ProfileGroupBox"
        Me.ProfileGroupBox.Size = New System.Drawing.Size(812, 549)
        Me.ProfileGroupBox.TabIndex = 0
        Me.ProfileGroupBox.TabStop = False
        Me.ProfileGroupBox.Text = "Profile"
        '
        'ProfileChangePasswordButton
        '
        Me.ProfileChangePasswordButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(78, Byte), Integer), CType(CType(184, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.ProfileChangePasswordButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ProfileChangePasswordButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.ProfileChangePasswordButton.Location = New System.Drawing.Point(29, 475)
        Me.ProfileChangePasswordButton.Name = "ProfileChangePasswordButton"
        Me.ProfileChangePasswordButton.Size = New System.Drawing.Size(279, 51)
        Me.ProfileChangePasswordButton.TabIndex = 24
        Me.ProfileChangePasswordButton.Text = "Change Password"
        Me.ProfileChangePasswordButton.UseVisualStyleBackColor = False
        '
        'ProfileMiscellaneousLabel
        '
        Me.ProfileMiscellaneousLabel.AutoSize = True
        Me.ProfileMiscellaneousLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProfileMiscellaneousLabel.ForeColor = System.Drawing.Color.AliceBlue
        Me.ProfileMiscellaneousLabel.Location = New System.Drawing.Point(627, 278)
        Me.ProfileMiscellaneousLabel.Name = "ProfileMiscellaneousLabel"
        Me.ProfileMiscellaneousLabel.Size = New System.Drawing.Size(138, 20)
        Me.ProfileMiscellaneousLabel.TabIndex = 4
        Me.ProfileMiscellaneousLabel.Text = "Only jpeg images"
        '
        'ProfileEditButton
        '
        Me.ProfileEditButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(78, Byte), Integer), CType(CType(184, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.ProfileEditButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ProfileEditButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.ProfileEditButton.Location = New System.Drawing.Point(428, 475)
        Me.ProfileEditButton.Name = "ProfileEditButton"
        Me.ProfileEditButton.Size = New System.Drawing.Size(118, 51)
        Me.ProfileEditButton.TabIndex = 23
        Me.ProfileEditButton.Text = "Edit"
        Me.ProfileEditButton.UseVisualStyleBackColor = False
        '
        'ProfileSaveProfileButton
        '
        Me.ProfileSaveProfileButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(78, Byte), Integer), CType(CType(184, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.ProfileSaveProfileButton.Enabled = False
        Me.ProfileSaveProfileButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ProfileSaveProfileButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.ProfileSaveProfileButton.Location = New System.Drawing.Point(621, 474)
        Me.ProfileSaveProfileButton.Name = "ProfileSaveProfileButton"
        Me.ProfileSaveProfileButton.Size = New System.Drawing.Size(172, 52)
        Me.ProfileSaveProfileButton.TabIndex = 22
        Me.ProfileSaveProfileButton.Text = "Save Profile"
        Me.ProfileSaveProfileButton.UseVisualStyleBackColor = False
        '
        'ProfileImageChangeButton
        '
        Me.ProfileImageChangeButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(78, Byte), Integer), CType(CType(184, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.ProfileImageChangeButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ProfileImageChangeButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.ProfileImageChangeButton.Location = New System.Drawing.Point(630, 222)
        Me.ProfileImageChangeButton.Name = "ProfileImageChangeButton"
        Me.ProfileImageChangeButton.Size = New System.Drawing.Size(134, 46)
        Me.ProfileImageChangeButton.TabIndex = 21
        Me.ProfileImageChangeButton.Text = "Change"
        Me.ProfileImageChangeButton.UseVisualStyleBackColor = False
        '
        'ProfileEmergencyContactNumberTextBox
        '
        Me.ProfileEmergencyContactNumberTextBox.Enabled = False
        Me.ProfileEmergencyContactNumberTextBox.Location = New System.Drawing.Point(438, 428)
        Me.ProfileEmergencyContactNumberTextBox.Name = "ProfileEmergencyContactNumberTextBox"
        Me.ProfileEmergencyContactNumberTextBox.Size = New System.Drawing.Size(355, 30)
        Me.ProfileEmergencyContactNumberTextBox.TabIndex = 20
        '
        'ProfileAddressTextBox
        '
        Me.ProfileAddressTextBox.Enabled = False
        Me.ProfileAddressTextBox.Location = New System.Drawing.Point(228, 387)
        Me.ProfileAddressTextBox.Name = "ProfileAddressTextBox"
        Me.ProfileAddressTextBox.Size = New System.Drawing.Size(565, 30)
        Me.ProfileAddressTextBox.TabIndex = 19
        '
        'ProfileContactNumberTextBox
        '
        Me.ProfileContactNumberTextBox.Enabled = False
        Me.ProfileContactNumberTextBox.Location = New System.Drawing.Point(438, 346)
        Me.ProfileContactNumberTextBox.Name = "ProfileContactNumberTextBox"
        Me.ProfileContactNumberTextBox.Size = New System.Drawing.Size(355, 30)
        Me.ProfileContactNumberTextBox.TabIndex = 18
        '
        'ProfileEmailTextBox
        '
        Me.ProfileEmailTextBox.Location = New System.Drawing.Point(184, 302)
        Me.ProfileEmailTextBox.Name = "ProfileEmailTextBox"
        Me.ProfileEmailTextBox.ReadOnly = True
        Me.ProfileEmailTextBox.Size = New System.Drawing.Size(355, 30)
        Me.ProfileEmailTextBox.TabIndex = 17
        '
        'ProfileGenderTextBox
        '
        Me.ProfileGenderTextBox.Location = New System.Drawing.Point(184, 258)
        Me.ProfileGenderTextBox.Name = "ProfileGenderTextBox"
        Me.ProfileGenderTextBox.ReadOnly = True
        Me.ProfileGenderTextBox.Size = New System.Drawing.Size(103, 30)
        Me.ProfileGenderTextBox.TabIndex = 16
        '
        'ProfileDepartmentTextBox
        '
        Me.ProfileDepartmentTextBox.Location = New System.Drawing.Point(184, 214)
        Me.ProfileDepartmentTextBox.Name = "ProfileDepartmentTextBox"
        Me.ProfileDepartmentTextBox.ReadOnly = True
        Me.ProfileDepartmentTextBox.Size = New System.Drawing.Size(103, 30)
        Me.ProfileDepartmentTextBox.TabIndex = 15
        '
        'ProfileRollNumberTextBox
        '
        Me.ProfileRollNumberTextBox.Location = New System.Drawing.Point(184, 161)
        Me.ProfileRollNumberTextBox.Name = "ProfileRollNumberTextBox"
        Me.ProfileRollNumberTextBox.ReadOnly = True
        Me.ProfileRollNumberTextBox.Size = New System.Drawing.Size(355, 30)
        Me.ProfileRollNumberTextBox.TabIndex = 14
        '
        'ProfileLastNameTextBox
        '
        Me.ProfileLastNameTextBox.Location = New System.Drawing.Point(184, 116)
        Me.ProfileLastNameTextBox.Name = "ProfileLastNameTextBox"
        Me.ProfileLastNameTextBox.ReadOnly = True
        Me.ProfileLastNameTextBox.Size = New System.Drawing.Size(355, 30)
        Me.ProfileLastNameTextBox.TabIndex = 13
        '
        'ProfileFirstNameTextBox
        '
        Me.ProfileFirstNameTextBox.Location = New System.Drawing.Point(184, 76)
        Me.ProfileFirstNameTextBox.Name = "ProfileFirstNameTextBox"
        Me.ProfileFirstNameTextBox.ReadOnly = True
        Me.ProfileFirstNameTextBox.Size = New System.Drawing.Size(355, 30)
        Me.ProfileFirstNameTextBox.TabIndex = 12
        '
        'ProfileUserNameTextBox
        '
        Me.ProfileUserNameTextBox.Location = New System.Drawing.Point(184, 35)
        Me.ProfileUserNameTextBox.Name = "ProfileUserNameTextBox"
        Me.ProfileUserNameTextBox.ReadOnly = True
        Me.ProfileUserNameTextBox.Size = New System.Drawing.Size(355, 30)
        Me.ProfileUserNameTextBox.TabIndex = 11
        '
        'ProfilePictureBox
        '
        Me.ProfilePictureBox.BackgroundImage = CType(resources.GetObject("ProfilePictureBox.BackgroundImage"), System.Drawing.Image)
        Me.ProfilePictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ProfilePictureBox.Location = New System.Drawing.Point(631, 29)
        Me.ProfilePictureBox.Name = "ProfilePictureBox"
        Me.ProfilePictureBox.Size = New System.Drawing.Size(162, 181)
        Me.ProfilePictureBox.TabIndex = 10
        Me.ProfilePictureBox.TabStop = False
        '
        'ProfileContactNumberLabel
        '
        Me.ProfileContactNumberLabel.AutoSize = True
        Me.ProfileContactNumberLabel.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProfileContactNumberLabel.ForeColor = System.Drawing.Color.White
        Me.ProfileContactNumberLabel.Location = New System.Drawing.Point(24, 351)
        Me.ProfileContactNumberLabel.Name = "ProfileContactNumberLabel"
        Me.ProfileContactNumberLabel.Size = New System.Drawing.Size(158, 24)
        Me.ProfileContactNumberLabel.TabIndex = 9
        Me.ProfileContactNumberLabel.Text = "Contact Number"
        '
        'ProfileAddressLabel
        '
        Me.ProfileAddressLabel.AutoSize = True
        Me.ProfileAddressLabel.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProfileAddressLabel.ForeColor = System.Drawing.Color.White
        Me.ProfileAddressLabel.Location = New System.Drawing.Point(24, 390)
        Me.ProfileAddressLabel.Name = "ProfileAddressLabel"
        Me.ProfileAddressLabel.Size = New System.Drawing.Size(81, 24)
        Me.ProfileAddressLabel.TabIndex = 8
        Me.ProfileAddressLabel.Text = "Address"
        '
        'ProfileEmergencyContactNumberLabel
        '
        Me.ProfileEmergencyContactNumberLabel.AutoSize = True
        Me.ProfileEmergencyContactNumberLabel.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProfileEmergencyContactNumberLabel.ForeColor = System.Drawing.Color.White
        Me.ProfileEmergencyContactNumberLabel.Location = New System.Drawing.Point(24, 428)
        Me.ProfileEmergencyContactNumberLabel.Name = "ProfileEmergencyContactNumberLabel"
        Me.ProfileEmergencyContactNumberLabel.Size = New System.Drawing.Size(260, 24)
        Me.ProfileEmergencyContactNumberLabel.TabIndex = 7
        Me.ProfileEmergencyContactNumberLabel.Text = "Emergency Contact number"
        '
        'ProfileEmailLabel
        '
        Me.ProfileEmailLabel.AutoSize = True
        Me.ProfileEmailLabel.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProfileEmailLabel.ForeColor = System.Drawing.Color.White
        Me.ProfileEmailLabel.Location = New System.Drawing.Point(24, 304)
        Me.ProfileEmailLabel.Name = "ProfileEmailLabel"
        Me.ProfileEmailLabel.Size = New System.Drawing.Size(63, 24)
        Me.ProfileEmailLabel.TabIndex = 6
        Me.ProfileEmailLabel.Text = "Email"
        '
        'ProfileGenderLabel
        '
        Me.ProfileGenderLabel.AutoSize = True
        Me.ProfileGenderLabel.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProfileGenderLabel.ForeColor = System.Drawing.Color.White
        Me.ProfileGenderLabel.Location = New System.Drawing.Point(24, 258)
        Me.ProfileGenderLabel.Name = "ProfileGenderLabel"
        Me.ProfileGenderLabel.Size = New System.Drawing.Size(76, 24)
        Me.ProfileGenderLabel.TabIndex = 5
        Me.ProfileGenderLabel.Text = "Gender"
        '
        'ProfileDepartmentLabel
        '
        Me.ProfileDepartmentLabel.AutoSize = True
        Me.ProfileDepartmentLabel.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProfileDepartmentLabel.ForeColor = System.Drawing.Color.White
        Me.ProfileDepartmentLabel.Location = New System.Drawing.Point(24, 214)
        Me.ProfileDepartmentLabel.Name = "ProfileDepartmentLabel"
        Me.ProfileDepartmentLabel.Size = New System.Drawing.Size(118, 24)
        Me.ProfileDepartmentLabel.TabIndex = 4
        Me.ProfileDepartmentLabel.Text = "Department"
        '
        'ProfileFirstNameLabel
        '
        Me.ProfileFirstNameLabel.AutoSize = True
        Me.ProfileFirstNameLabel.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProfileFirstNameLabel.ForeColor = System.Drawing.Color.White
        Me.ProfileFirstNameLabel.Location = New System.Drawing.Point(24, 76)
        Me.ProfileFirstNameLabel.Name = "ProfileFirstNameLabel"
        Me.ProfileFirstNameLabel.Size = New System.Drawing.Size(110, 24)
        Me.ProfileFirstNameLabel.TabIndex = 3
        Me.ProfileFirstNameLabel.Text = "First Name"
        '
        'ProfileLastNameLabel
        '
        Me.ProfileLastNameLabel.AutoSize = True
        Me.ProfileLastNameLabel.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProfileLastNameLabel.ForeColor = System.Drawing.Color.White
        Me.ProfileLastNameLabel.Location = New System.Drawing.Point(24, 116)
        Me.ProfileLastNameLabel.Name = "ProfileLastNameLabel"
        Me.ProfileLastNameLabel.Size = New System.Drawing.Size(106, 24)
        Me.ProfileLastNameLabel.TabIndex = 2
        Me.ProfileLastNameLabel.Text = "Last Name"
        '
        'ProfileRollNumberLabel
        '
        Me.ProfileRollNumberLabel.AutoSize = True
        Me.ProfileRollNumberLabel.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProfileRollNumberLabel.ForeColor = System.Drawing.Color.White
        Me.ProfileRollNumberLabel.Location = New System.Drawing.Point(24, 162)
        Me.ProfileRollNumberLabel.Name = "ProfileRollNumberLabel"
        Me.ProfileRollNumberLabel.Size = New System.Drawing.Size(126, 24)
        Me.ProfileRollNumberLabel.TabIndex = 1
        Me.ProfileRollNumberLabel.Text = "Roll Number"
        '
        'ProfileUserNameLabel
        '
        Me.ProfileUserNameLabel.AutoSize = True
        Me.ProfileUserNameLabel.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProfileUserNameLabel.ForeColor = System.Drawing.Color.White
        Me.ProfileUserNameLabel.Location = New System.Drawing.Point(24, 35)
        Me.ProfileUserNameLabel.Name = "ProfileUserNameLabel"
        Me.ProfileUserNameLabel.Size = New System.Drawing.Size(110, 24)
        Me.ProfileUserNameLabel.TabIndex = 0
        Me.ProfileUserNameLabel.Text = "User Name"
        '
        'ProfilePanel
        '
        Me.ProfilePanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ProfilePanel.Controls.Add(Me.ProfileGroupBox)
        Me.ProfilePanel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ProfilePanel.Location = New System.Drawing.Point(312, 130)
        Me.ProfilePanel.Name = "ProfilePanel"
        Me.ProfilePanel.Size = New System.Drawing.Size(842, 575)
        Me.ProfilePanel.TabIndex = 5
        '
        'Student_HomePage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1232, 795)
        Me.Controls.Add(Me.NAGroupBox)
        Me.Controls.Add(Me.ProfilePasswordChangePanel)
        Me.Controls.Add(Me.ExtendOuterPanel)
        Me.Controls.Add(Me.ProfilePanel)
        Me.Controls.Add(Me.OldPanel)
        Me.Controls.Add(Me.NavigationouterPanel)
        Me.Controls.Add(Me.HeadingLabel)
        Me.Controls.Add(Me.UsernameLabel)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Student_HomePage"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Student Homepage"
        Me.NavigationGroupBox.ResumeLayout(False)
        Me.NAGroupBox.ResumeLayout(False)
        Me.NAInnerPanel.ResumeLayout(False)
        Me.NAInnerPanel.PerformLayout()
        Me.OldPanel.ResumeLayout(False)
        Me.OldInnerPanel.ResumeLayout(False)
        Me.OldInnerPanel.PerformLayout()
        Me.OldUpcomingLeavesPanel.ResumeLayout(False)
        Me.OldPastLeavesPanel.ResumeLayout(False)
        Me.NavigationouterPanel.ResumeLayout(False)
        Me.ProfilePasswordChangePanel.ResumeLayout(False)
        Me.ProfilePasswordChangeGroupBox.ResumeLayout(False)
        Me.ProfilePasswordChangeGroupBox.PerformLayout()
        Me.ExtendOuterPanel.ResumeLayout(False)
        Me.ExtendleavePanel.ResumeLayout(False)
        Me.ExtendleavePanel.PerformLayout()
        Me.ProfileGroupBox.ResumeLayout(False)
        Me.ProfileGroupBox.PerformLayout()
        CType(Me.ProfilePictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ProfilePanel.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents NavigationGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents LogOutButton As System.Windows.Forms.Button
    Friend WithEvents ProfileButton As System.Windows.Forms.Button
    Friend WithEvents OldButton As System.Windows.Forms.Button
    Friend WithEvents NAButton As System.Windows.Forms.Button
    Friend WithEvents NAGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents UsernameLabel As System.Windows.Forms.Label
    Friend WithEvents HeadingLabel As System.Windows.Forms.Label
    Friend WithEvents ProfileOpenFileDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents NAOpenFileDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents OldPanel As System.Windows.Forms.Panel
    Friend WithEvents OldUpcomingleaveLabel As System.Windows.Forms.Label
    Friend WithEvents OldPastLeaveLabel As System.Windows.Forms.Label
    Friend WithEvents OldUpcomingLeavesPanel As System.Windows.Forms.Panel
    Friend WithEvents OldPastLeavesPanel As System.Windows.Forms.Panel
    Friend WithEvents OldUpcomingLeaveListBox As System.Windows.Forms.ListBox
    Friend WithEvents OldPastLeaveListBox As System.Windows.Forms.ListBox
    Friend WithEvents OldDeleteButton As System.Windows.Forms.Button
    Friend WithEvents OldCommentsListBox As System.Windows.Forms.ListBox
    Friend WithEvents OldCommentsLabel As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents NAParentalLeavesLabel As System.Windows.Forms.Label
    Friend WithEvents NAAcademicLeavesLabel As System.Windows.Forms.Label
    Friend WithEvents NAMedicalLeavesLabel As System.Windows.Forms.Label
    Friend WithEvents NAOrdinaryleavesLabel As System.Windows.Forms.Label
    Friend WithEvents OldExtendLeaveButton As System.Windows.Forms.Button
    Friend WithEvents ExtendOpenFileDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents NavigationouterPanel As System.Windows.Forms.Panel
    Friend WithEvents OldInnerPanel As System.Windows.Forms.Panel
    Friend WithEvents ProfilePasswordChangePanel As System.Windows.Forms.Panel
    Friend WithEvents ProfilePasswordChangeGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents ProfilePasswordCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents ProfilePasswordOkButton As System.Windows.Forms.Button
    Friend WithEvents ProfilePasswordCancelButton As System.Windows.Forms.Button
    Friend WithEvents ProfileNewPasswordTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ProfileConfirmNewPasswordTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ProfileOldPasswordTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ProfileConfirmNewPasswordLabel As System.Windows.Forms.Label
    Friend WithEvents ProfileNewPasswordLabel As System.Windows.Forms.Label
    Friend WithEvents ProfileOldPasswordLabel As System.Windows.Forms.Label
    Friend WithEvents ExtendOuterPanel As System.Windows.Forms.Panel
    Friend WithEvents ExtendleavePanel As System.Windows.Forms.Panel
    Friend WithEvents ExtendLeaveInstructionTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ExtendLeaveUploadButton As System.Windows.Forms.Button
    Friend WithEvents ExtendLeaveApplyButton As System.Windows.Forms.Button
    Friend WithEvents ExtendLeaveCancelButton As System.Windows.Forms.Button
    Friend WithEvents ExtendLeaveNewDocumentsLabel As System.Windows.Forms.Label
    Friend WithEvents ExtendLeaveLastDateLabel As System.Windows.Forms.Label
    Friend WithEvents ExtendLastDateDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents NAInnerPanel As System.Windows.Forms.Panel
    Friend WithEvents NASupervisorLabel As System.Windows.Forms.Label
    Friend WithEvents NASupervisorComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents NAInstructionTextBox As System.Windows.Forms.TextBox
    Friend WithEvents NAUploadButton As System.Windows.Forms.Button
    Friend WithEvents NAApplyButton As System.Windows.Forms.Button
    Friend WithEvents NALeaveTypeComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents NALastDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents NAStartDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents NALastNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents NAFirstnameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents NADocumentsLabel As System.Windows.Forms.Label
    Friend WithEvents NALastDateLabel As System.Windows.Forms.Label
    Friend WithEvents NAStartDateLabel As System.Windows.Forms.Label
    Friend WithEvents NALeaveTypeLabel As System.Windows.Forms.Label
    Friend WithEvents NALastNameLabel As System.Windows.Forms.Label
    Friend WithEvents NAFirstNameLabel As System.Windows.Forms.Label
    Friend WithEvents ProfileGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents ProfileChangePasswordButton As System.Windows.Forms.Button
    Friend WithEvents ProfileMiscellaneousLabel As System.Windows.Forms.Label
    Friend WithEvents ProfileEditButton As System.Windows.Forms.Button
    Friend WithEvents ProfileSaveProfileButton As System.Windows.Forms.Button
    Friend WithEvents ProfileImageChangeButton As System.Windows.Forms.Button
    Friend WithEvents ProfileEmergencyContactNumberTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ProfileAddressTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ProfileContactNumberTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ProfileEmailTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ProfileGenderTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ProfileDepartmentTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ProfileRollNumberTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ProfileLastNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ProfileFirstNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ProfileUserNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ProfilePictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents ProfileContactNumberLabel As System.Windows.Forms.Label
    Friend WithEvents ProfileAddressLabel As System.Windows.Forms.Label
    Friend WithEvents ProfileEmergencyContactNumberLabel As System.Windows.Forms.Label
    Friend WithEvents ProfileEmailLabel As System.Windows.Forms.Label
    Friend WithEvents ProfileGenderLabel As System.Windows.Forms.Label
    Friend WithEvents ProfileDepartmentLabel As System.Windows.Forms.Label
    Friend WithEvents ProfileFirstNameLabel As System.Windows.Forms.Label
    Friend WithEvents ProfileLastNameLabel As System.Windows.Forms.Label
    Friend WithEvents ProfileRollNumberLabel As System.Windows.Forms.Label
    Friend WithEvents ProfileUserNameLabel As System.Windows.Forms.Label
    Friend WithEvents ProfilePanel As System.Windows.Forms.Panel
End Class
