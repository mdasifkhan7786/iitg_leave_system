# IITG-Leave System
Windows Application to applying for leaves for MTech, PhD students and staff.
